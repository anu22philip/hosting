new WOW().init();
